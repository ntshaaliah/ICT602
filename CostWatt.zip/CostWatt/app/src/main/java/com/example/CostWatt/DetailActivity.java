package com.example.CostWatt;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    private TextView tvMonth, tvUnits, tvTotalCharges, tvRebate, tvFinalCost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        tvMonth = findViewById(R.id.tvMonth);
        tvUnits = findViewById(R.id.tvUnits);
        tvTotalCharges = findViewById(R.id.tvTotalCharges);
        tvRebate = findViewById(R.id.tvRebate);
        tvFinalCost = findViewById(R.id.tvFinalCost);

        int billId = getIntent().getIntExtra("bill_id", -1);

        if (billId != -1) {
            loadBillDetails(billId);
        } else {
            tvMonth.setText("No details found");
        }
    }

    private void loadBillDetails(int id) {
        DBHelper dbHelper = new DBHelper(this);
        Cursor cursor = dbHelper.getBillById(id);

        if (cursor != null && cursor.moveToFirst()) {
            String month = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_MONTH));
            int units = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.COL_UNITS));
            double totalCharges = cursor.getDouble(cursor.getColumnIndexOrThrow(DBHelper.COL_TOTAL_CHARGES));
            double rebate = cursor.getDouble(cursor.getColumnIndexOrThrow(DBHelper.COL_REBATE));
            double finalCost = cursor.getDouble(cursor.getColumnIndexOrThrow(DBHelper.COL_FINAL_COST));

            tvMonth.setText("Month: " + month);
            tvUnits.setText("Units Used: " + units + " kWh");
            tvTotalCharges.setText(String.format("Total Charges: RM %.2f", totalCharges));
            tvRebate.setText(String.format("Rebate: %.0f%%", rebate * 100));
            tvFinalCost.setText(String.format("Final Cost: RM %.2f", finalCost));

            cursor.close();
        } else {
            tvMonth.setText("No details found");
        }
    }
}
