package com.example.CostWatt;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    Spinner spinnerMonth, spinnerRebate;
    EditText editTextUnit;
    TextView textTotalCharge, textFinalCost;
    Button buttonCalculate, buttonSave;
    DBHelper db;

    String[] months = {"January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"};
    String[] rebates = {"0", "1", "2", "3", "4", "5"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DBHelper(this);

        spinnerMonth = findViewById(R.id.spinnerMonth);
        spinnerRebate = findViewById(R.id.spinnerRebate);
        editTextUnit = findViewById(R.id.editTextUnit);
        textTotalCharge = findViewById(R.id.textTotalCharge);
        textFinalCost = findViewById(R.id.textFinalCost);
        buttonCalculate = findViewById(R.id.buttonCalculate);
        buttonSave = findViewById(R.id.buttonSave);

        ArrayAdapter<String> monthAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, months);
        monthAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMonth.setAdapter(monthAdapter);

        ArrayAdapter<String> rebateAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, rebates);
        rebateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRebate.setAdapter(rebateAdapter);

        buttonCalculate.setOnClickListener(v -> calculateBill());
        buttonSave.setOnClickListener(v -> saveToDatabase());

        // Bottom Navigation Setup
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                // Already on Home
                return true;
            } else if (id == R.id.nav_history) {
                startActivity(new Intent(MainActivity.this, HistoryActivity.class));
                return true;
            } else if (id == R.id.nav_about) {
                startActivity(new Intent(MainActivity.this, AboutActivity.class));
                return true;
            }
            return false;
        });
    }

    private double calculateCharge(int units) {
        double total = 0;
        if (units <= 200)
            total = units * 0.218;
        else if (units <= 300)
            total = 200 * 0.218 + (units - 200) * 0.334;
        else if (units <= 600)
            total = 200 * 0.218 + 100 * 0.334 + (units - 300) * 0.516;
        else
            total = 200 * 0.218 + 100 * 0.334 + 300 * 0.516 + (units - 600) * 0.546;
        return total;
    }

    private void calculateBill() {
        String unitStr = editTextUnit.getText().toString().trim();

        if (unitStr.isEmpty()) {
            editTextUnit.setError("Please enter electricity usage in kWh");
            Toast.makeText(this, "Units field cannot be empty!", Toast.LENGTH_SHORT).show();
            return;
        }

        int units;
        try {
            units = Integer.parseInt(unitStr);
            if (units <= 0) {
                editTextUnit.setError("Units must be greater than 0");
                Toast.makeText(this, "Please enter a positive number", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (NumberFormatException e) {
            editTextUnit.setError("Invalid number");
            Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
            return;
        }

        double rebate = Double.parseDouble(spinnerRebate.getSelectedItem().toString());
        double total = calculateCharge(units);
        double finalCost = total - (total * (rebate / 100));

        textTotalCharge.setText("Total Charge: RM " + String.format("%.2f", total));
        textFinalCost.setText("Final Cost: RM " + String.format("%.2f", finalCost));

        Toast.makeText(this, "Calculation successful! You can now save the result.", Toast.LENGTH_LONG).show();
    }

    private void saveToDatabase() {
        String unitStr = editTextUnit.getText().toString().trim();
        if (unitStr.isEmpty()) {
            editTextUnit.setError("Please calculate before saving.");
            Toast.makeText(this, "Unit is required before saving.", Toast.LENGTH_SHORT).show();
            return;
        }

        int units;
        try {
            units = Integer.parseInt(unitStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid unit input.", Toast.LENGTH_SHORT).show();
            return;
        }

        String month = spinnerMonth.getSelectedItem().toString();
        double rebate = Double.parseDouble(spinnerRebate.getSelectedItem().toString());
        double total = calculateCharge(units);
        double finalCost = total - (total * (rebate / 100));

        long result = db.insertBill(month, units, total, rebate, finalCost);
        if (result != -1) {
            Toast.makeText(this, "Data saved to database.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error saving data.", Toast.LENGTH_SHORT).show();
        }
    }
}
