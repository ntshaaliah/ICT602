package com.example.CostWatt;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "ElectricityBills.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_BILLS = "bills";
    public static final String COL_ID = "id";
    public static final String COL_MONTH = "month";
    public static final String COL_UNITS = "units";
    public static final String COL_TOTAL_CHARGES = "total_charges";
    public static final String COL_REBATE = "rebate";
    public static final String COL_FINAL_COST = "final_cost";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Called when the database is created for the first time
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_BILLS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_MONTH + " TEXT, " +
                COL_UNITS + " INTEGER, " +
                COL_TOTAL_CHARGES + " REAL, " +
                COL_REBATE + " REAL, " +
                COL_FINAL_COST + " REAL" +
                ")";
        db.execSQL(createTable);
    }

    // Called when database version changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop old table if exists and recreate
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BILLS);
        onCreate(db);
    }

    // Insert a new bill (optional helper method)
    public long insertBill(String month, int units, double totalCharges, double rebate, double finalCost) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_MONTH, month);
        values.put(COL_UNITS, units);
        values.put(COL_TOTAL_CHARGES, totalCharges);
        values.put(COL_REBATE, rebate);
        values.put(COL_FINAL_COST, finalCost);

        return db.insert(TABLE_BILLS, null, values);
    }

    // Get a Cursor for a bill by ID
    public Cursor getBillById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_BILLS, null, COL_ID + "=?", new String[]{String.valueOf(id)}, null, null, null);
    }

    // Get a Cursor for all bills
    public Cursor getAllBills() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_BILLS, null, null, null, null, null, COL_ID + " DESC");
    }
}
