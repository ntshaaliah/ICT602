package com.example.CostWatt;

public class BillModel {
    private int id;
    private String month;
    private int units;
    private double totalCharges;
    private double rebate;
    private double finalCost;

    public BillModel(int id, String month, int units, double totalCharges, double rebate, double finalCost) {
        this.id = id;
        this.month = month;
        this.units = units;
        this.totalCharges = totalCharges;
        this.rebate = rebate;
        this.finalCost = finalCost;
    }

    public int getId() {
        return id;
    }

    public String getMonth() {
        return month;
    }

    public int getUnits() {
        return units;
    }

    public double getTotalCharges() {
        return totalCharges;
    }

    public double getRebate() {
        return rebate;
    }

    public double getFinalCost() {
        return finalCost;
    }
}
