package com.example.CostWatt;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.HashMap;

public class HistoryActivity extends AppCompatActivity {

    ListView lvBills;
    DBHelper dbHelper;
    BottomNavigationView bottomNavigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        lvBills = findViewById(R.id.lvBills);
        dbHelper = new DBHelper(this);
        bottomNavigation = findViewById(R.id.bottomNavigation);

        loadBills();

        // Set current selected item
        bottomNavigation.setSelectedItemId(R.id.nav_history);

        // Handle bottom navigation item clicks
        bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                startActivity(new Intent(HistoryActivity.this, MainActivity.class));
                overridePendingTransition(0, 0);
                return true;
            } else if (itemId == R.id.nav_history) {
                return true; // Already on history page
            } else if (itemId == R.id.nav_about) {
                startActivity(new Intent(HistoryActivity.this, AboutActivity.class));
                overridePendingTransition(0, 0);
                return true;
            }
            return false;
        });
    }

    private void loadBills() {
        Cursor cursor = dbHelper.getAllBills();

        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No history found", Toast.LENGTH_SHORT).show();
            return;
        }

        ArrayList<HashMap<String, String>> billList = new ArrayList<>();

        while (cursor.moveToNext()) {
            HashMap<String, String> map = new HashMap<>();
            String month = cursor.getString(cursor.getColumnIndexOrThrow("month"));
            int units = cursor.getInt(cursor.getColumnIndexOrThrow("units"));
            double totalCharges = cursor.getDouble(cursor.getColumnIndexOrThrow("total_charges"));
            double rebate = cursor.getDouble(cursor.getColumnIndexOrThrow("rebate"));
            double finalCost = cursor.getDouble(cursor.getColumnIndexOrThrow("final_cost"));

            map.put("month", month);
            map.put("details", String.format("Units: %d, Total: RM %.2f, Rebate: %.2f%%, Final: RM %.2f",
                    units, totalCharges, rebate * 100, finalCost));

            billList.add(map);
        }
        cursor.close();

        String[] from = {"month", "details"};
        int[] to = {R.id.tvMonth, R.id.tvDetails};

        SimpleAdapter adapter = new SimpleAdapter(this, billList, R.layout.list_item_bill, from, to);
        lvBills.setAdapter(adapter);
    }
}
